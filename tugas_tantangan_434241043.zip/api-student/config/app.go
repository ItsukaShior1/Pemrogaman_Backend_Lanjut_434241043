package config

import (
	"github.com/gofiber/fiber/v2"

	"github.com/jackc/pgx/v5/pgxpool"
)

type AppConfig struct {
	Fiber  *fiber.App
	DBPool *pgxpool.Pool
	Logger *AppLogger
}
